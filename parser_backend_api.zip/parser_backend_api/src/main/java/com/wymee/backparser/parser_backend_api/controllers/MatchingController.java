package com.wymee.backparser.parser_backend_api.controllers;

import com.wymee.backparser.parser_backend_api.classes.JobObject;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

public class MatchingController {

    @GetMapping("/match")
    public static String match(){

        //Créer ici la recupération des données à macther

        List<JobObject> jobList = new ArrayList<>();

        //TODO Getting MySQL data for matching

        return jobList.toString();
    }

    public static String matches(String candidat){
        JSONObject candidate = new JSONObject(candidat);

        // TODO getting SQLData and matching it to return it has a json Object to String!

        return candidate.toString();
    }
} 
