package com.wymee.backparser.parser_backend_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParserBackendApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
